package clases;

public class Main {
    public static void main(String[] args) {
     
        Curso curso = new Curso();

      
        Estudiante estudiante1 = new Estudiante("Juan", "Gómez", 101, 1, 88);
        Estudiante estudiante2 = new Estudiante("María", "López", 102, 1, 92);
        Estudiante estudiante3 = new Estudiante("Carlos", "Ramírez", 103, 1, 75);

  
        if(curso.añadir(estudiante1)) {
            System.out.println("Se añadió a " + estudiante1.getNombre());
        }
        if(curso.añadir(estudiante2)) {
            System.out.println("Se añadió a " + estudiante2.getNombre());
        }
        if(curso.añadir(estudiante3)) {
            System.out.println("Se añadió a " + estudiante3.getNombre());
        }

  
        System.out.println("Cantidad de estudiantes: " + curso.obtenerCantidad());

 
        System.out.println("Promedio de notas: " + curso.calcularPromedio());

 
        int codigoEliminar = 102;
        if (curso.eliminar(codigoEliminar)) {
            System.out.println("Estudiante con código " + codigoEliminar + " eliminado.");
        } else {
            System.out.println("No se encontró al estudiante con código " + codigoEliminar);
        }


        System.out.println("Cantidad de estudiantes después de eliminar: " + curso.obtenerCantidad());
        System.out.println("Nuevo promedio de notas: " + curso.calcularPromedio());
    }
}
