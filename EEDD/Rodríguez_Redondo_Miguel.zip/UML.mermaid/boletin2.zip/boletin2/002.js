let entrada = prompt("Ingresa una lista con 🐵 y 🍌 (ej: 🐵🍌🍌🍌🐵🍌🐵🍌):");
let cantidadMonos = (entrada.match(/🐵/g) || []).length;
let cantidadBananas = (entrada.match(/🍌/g) || []).length;
let bananasPorMono = parseInt(prompt("¿Cuántas bananas come cada mono?"), 10);
let bananasNecesarias = cantidadMonos * bananasPorMono;

if (cantidadBananas >= bananasNecesarias) {
    alert(`Hay suficientes bananas para los ${cantidadMonos} monos. `);
} else {
    alert("¡Oh no! ¡No hay suficientes bananas para los monos! 😭");
}
