let comida = prompt("¿Vas a almorzar o cenar?");
let esVegetariano = prompt("¿Eres vegetariano? (sí/no)");

let plato;

if (comida === "almorzar" && esVegetariano === "sí") {
    plato = "🥬 Espinacas con garbanzos";
} else if (comida === "almorzar" && esVegetariano === "no") {
    plato = "🍝 Macarrones con pollo y setas";
} else if (comida === "cenar" && esVegetariano === "sí") {
    plato = "🥪 Sandwich vegetal";
} else if (comida === "cenar" && esVegetariano === "no") {
    plato = "🍕 Pizza";
}

alert("Te recomendamos: " + plato);
