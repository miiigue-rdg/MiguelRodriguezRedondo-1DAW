let cumpleDia = 10;
let cumpleMes = 8;
let vidas = 10;
let haAdivinado = false;

while (vidas > 0 && !haAdivinado) {
    let dia = parseInt(prompt("Adivina el *DÍA* de mi cumpleaños (1-31):"), 10);
    let mes = parseInt(prompt("Adivina el *MES* de mi cumpleaños (1-12):"), 10);

    if (dia === cumpleDia && mes === cumpleMes) {
        haAdivinado = true;
        break;
    } else {
        if (dia !== cumpleDia && mes !== cumpleMes) {
            alert("¡Fallaste el día y el mes! 😬");
        } else if (dia !== cumpleDia) {
            alert("El mes está bien, pero el día es incorrecto. 📅❌");
        } else {
            alert("El día está bien, pero el mes es incorrecto. 📆❌");
        }
        vidas--;
        alert("Vidas restantes: " + "💚".repeat(vidas));
        let seguir = prompt("¿Quieres seguir jugando? (sí/no)");
        if (seguir.toLowerCase() !== "sí") {
            break;
        }
    }
}

if (haAdivinado) {
    alert("¡Has ganado! 🏅");
} else {
    alert("Has perdido 😿 !!!");
}
