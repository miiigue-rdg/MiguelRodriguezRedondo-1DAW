let ing1 = prompt("¿Tienes cebolla? (sí/no)").toLowerCase() === "sí";
let ing2 = prompt("¿Tienes arroz? (sí/no)").toLowerCase() === "sí";
let ing3 = prompt("¿Tienes pollo? (sí/no)").toLowerCase() === "sí";
let ing4 = prompt("¿Tienes pan? (sí/no)").toLowerCase() === "sí";
let ing5 = prompt("¿Tienes bacon? (sí/no)").toLowerCase() === "sí";

let comidas = [];

if (ing1 && ing2 && ing3 && ing4 && ing5) {
    comidas.push("🍲 Super combo: arroz con pollo, cebolla y bacon servido con pan");
}

if (
    (ing1 && ing2 && ing3 && ing4) ||
    (ing1 && ing2 && ing3 && ing5) ||
    (ing1 && ing2 && ing4 && ing5) ||
    (ing1 && ing3 && ing4 && ing5) ||
    (ing2 && ing3 && ing4 && ing5)
) {
    comidas.push("🍛 Arroz salteado con cebolla, pollo y bacon");
    comidas.push("🥪 Sándwich de pollo, bacon y cebolla");
}

if (
    (ing1 && ing2 && ing3) ||
    (ing1 && ing2 && ing5) ||
    (ing2 && ing3 && ing5) ||
    (ing3 && ing4 && ing5) ||
    (ing1 && ing4 && ing5)
) {
    comidas.push("🍗 Pollo con arroz y cebolla");
    comidas.push("🥓 Pan con bacon y pollo");
}

if (
    (ing1 && ing2) ||
    (ing2 && ing3) ||
    (ing4 && ing5) ||
    (ing3 && ing5) ||
    (ing2 && ing5)
) {
    comidas.push("🍳 Arroz con bacon");
    comidas.push("🥖 Bocadillo de bacon");
}

if (comidas.length > 0) {
    alert("Puedes cocinar:\n\n" + comidas.join("\n"));
} else {
    alert("No tienes suficientes ingredientes para preparar ninguna receta 😢");
}
