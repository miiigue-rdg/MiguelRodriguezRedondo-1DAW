function validarTarjeta(cadena) {
    let numero = cadena.replace(/\D/g, "");

    function pasaLuhn(num) {
        let suma = 0;
        let longitud = num.length;
        for (let i = 0; i < longitud; i++) {
            let digito = parseInt(num[longitud - 1 - i]);
            if ((i + 1) % 2 === 0) {
                digito *= 2;
                if (digito > 9) digito -= 9;
            }
            suma += digito;
        }
        return suma % 10 === 0;
    }

    if (!/^\d+$/.test(numero) || !pasaLuhn(numero)) {
        return "invalid ❌";
    }

    if ((numero.startsWith("34") || numero.startsWith("37")) && numero.length === 15) {
        return "American Express 💳 ✅";
    } else if (numero.startsWith("4") && (numero.length === 13 || numero.length === 16)) {
        return "Visa 💳 ✅";
    } else if (/^5[1-5]/.test(numero) && numero.length === 16) {
        return "MasterCard 💳 ✅";
    } else {
        return "invalid ❌";
    }
}

let tarjeta = prompt("Introduzca el número de la tarjeta (sin guiones):");
let resultado = validarTarjeta(tarjeta);
alert(resultado);
