let rachaActual = 0;
let rachaMaxima = 0;

while (true) {
    let eleccion = prompt("Elige: CARA (🪙), CRUZ (✖️) o SALIR (🚪)").toLowerCase();

    if (eleccion === "salir" || eleccion === "🚪") {
        alert("👋 ¡Hasta pronto! Tu mejor racha fue de " + rachaMaxima + " aciertos seguidos.");
        break;
    }

    let opcionesValidas = ["cara", "🪙", "cruz", "✖️"];
    if (!opcionesValidas.includes(eleccion)) {
        alert("Opción no válida. Elige CARA, CRUZ o SALIR.");
        continue;
    }

    let resultado = Math.random() < 0.5 ? "cara" : "cruz";
    let emojiResultado = resultado === "cara" ? "🪙" : "✖️";

    let gano =
        (eleccion === "cara" || eleccion === "🪙") && resultado === "cara" ||
        (eleccion === "cruz" || eleccion === "✖️") && resultado === "cruz";

    if (gano) {
        rachaActual++;
        if (rachaActual > rachaMaxima) {
            rachaMaxima = rachaActual;
        }
        alert("¡Acertaste! Resultado: " + emojiResultado + "\nRacha actual: " + rachaActual);
    } else {
        rachaActual = 0;
        alert("¡Fallaste! Resultado: " + emojiResultado + "\nRacha reiniciada.");
    }
}
