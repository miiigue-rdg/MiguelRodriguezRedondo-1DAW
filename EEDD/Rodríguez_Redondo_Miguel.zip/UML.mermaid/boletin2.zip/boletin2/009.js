let colores = ["🔴", "🔵", "🟢", "🟡"];
let secuencia = [];
let rondas = 0;
let maxRondas = prompt("¿Cuántas rondas quieres jugar? (Deja vacío para jugar indefinidamente)");

if (maxRondas !== "") {
    maxRondas = parseInt(maxRondas);
}

let continuar = true;

while (continuar) {
    rondas++;
    let nuevoColor = colores[Math.floor(Math.random() * colores.length)];
    secuencia.push(nuevoColor);

    alert("Secuencia de colores:\n" + secuencia.join(" "));

    for (let i = 0; i < secuencia.length; i++) {
        let respuesta = prompt("Color #" + (i + 1)).trim();
        if (respuesta !== secuencia[i]) {
            alert("¡Fallaste! 😵 La secuencia era:\n" + secuencia.join(" ") + "\nSobreviviste " + (rondas - 1) + " ronda(s).");
            continuar = false;
            break;
        }
    }

    if (continuar && maxRondas && rondas === maxRondas) {
        alert("¡Ganaste! 🏆 Completaste las " + maxRondas + " rondas.");
        break;
    }
}
