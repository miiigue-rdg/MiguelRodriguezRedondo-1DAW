let vidaJugador = 100;   // ❤️
let vidaMonstruo = 120;  // 💜
let pociones = 3;        // 🧪
let ataqueMaxJugador = 25; // ⚔️
let ataqueMaxMonstruo = 20; // 👾
let curacionMax = 30;    // 🩺

alert("¡Comienza la batalla! 🧝‍♀️ VS 👾");

while (vidaJugador > 0 && vidaMonstruo > 0) {
    let accion = prompt(
        "Elige una acción:\n\n" +
        "1. ATACAR MONSTRUO ⚔️\n" +
        "2. TOMAR POCIÓN 🧪\n" +
        "3. BUSCAR POCIÓN 🔍\n" +
        "4. SALIR 🚪"
    );

    if (accion === "4" || accion.toLowerCase() === "salir") {
        alert("Has escapado de la batalla. 🏃‍♂️");
        break;
    }

    let mensaje = "";

    if (accion === "1") {
        let daño = Math.floor(Math.random() * ataqueMaxJugador) + 1;
        vidaMonstruo -= daño;
        mensaje += `Atacaste al monstruo y le hiciste ${daño} de daño. ⚔️\n`;
    } else if (accion === "2") {
        if (pociones > 0) {
            let curacion = Math.floor(Math.random() * curacionMax) + 1;
            vidaJugador += curacion;
            pociones--;
            mensaje += `Usaste una poción y recuperaste ${curacion} de vida. 🩺\n`;
        } else {
            mensaje += "No te quedan pociones. ❌\n";
        }
    } else if (accion === "3") {
        let resultado = Math.floor(Math.random() * 4) + 1;
        if (resultado === 1) {
            pociones++;
            mensaje += "¡Encontraste una poción nueva! 🧪\n";
        } else {
            mensaje += "Buscaste y no encontraste nada. 🔍\n";
        }
    } else {
        mensaje += "Acción no válida. Intenta de nuevo.\n";
        alert(mensaje);
        continue;
    }

    if (vidaMonstruo > 0) {
        let dañoMonstruo = Math.floor(Math.random() * ataqueMaxMonstruo) + 1;
        vidaJugador -= dañoMonstruo;
        mensaje += `El monstruo te atacó y te hizo ${dañoMonstruo} de daño. 👾\n`;
    }

    mensaje += `\n❤️ Vida jugador/a: ${vidaJugador < 0 ? 0 : vidaJugador}\n💜 Vida monstruo: ${vidaMonstruo < 0 ? 0 : vidaMonstruo}\n🧪 Pociones: ${pociones}`;

    alert(mensaje);
}

if (vidaJugador <= 0 && vidaMonstruo <= 0) {
    alert("¡Ambos han caído en batalla! ⚔️😵");
} else if (vidaJugador <= 0) {
    alert("¡Has sido derrotado por el monstruo! 💀👾");
} else if (vidaMonstruo <= 0) {
    alert("¡Has vencido al monstruo! 🎉🏆");
}