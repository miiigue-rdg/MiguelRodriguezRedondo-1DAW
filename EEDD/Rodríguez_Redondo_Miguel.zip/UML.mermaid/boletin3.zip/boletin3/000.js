// 000practiseBasics.js

// 1. Declara un array vacío
let emptyArray = [];

// 2. Declara un array con más de 5 elementos
let numbers = [1, 2, 3, 4, 5, 6, 7];

// 3. Encuentra la longitud del array
console.log("Longitud:", numbers.length);

// 4. Primer, medio y último elemento
console.log("Primero:", numbers[0]);
console.log("Medio:", numbers[Math.floor(numbers.length / 2)]);
console.log("Último:", numbers[numbers.length - 1]);

// 5. mixedDataTypes
let mixedDataTypes = [1, "texto", true, null, undefined, [2, 3], { a: 1 }];
console.log("mixedDataTypes longitud:", mixedDataTypes.length);

// 6. itCompanies
let itCompanies = ["Facebook", "Google", "Microsoft", "Apple", "IBM", "Oracle", "Amazon"];

// 7. Imprimir array
console.log(itCompanies);

// 8. Número de empresas
console.log("Número de empresas:", itCompanies.length);

// 9. Primera, intermedia y última empresa
console.log("Primera:", itCompanies[0]);
console.log("Intermedia:", itCompanies[Math.floor(itCompanies.length / 2)]);
console.log("Última:", itCompanies[itCompanies.length - 1]);

// 10. Imprimir cada empresa
itCompanies.forEach(company => console.log(company));

// 11. Empresas en mayúsculas
itCompanies.forEach(company => console.log(company.toUpperCase()));

// 12. Como oración
console.log(`${itCompanies.join(", ")} son grandes empresas de TI.`);

// 13. Comprobar existencia
let empresa = "Google";
if (itCompanies.includes(empresa)) {
  console.log(empresa);
} else {
  console.log("La empresa no existe");
}

// 14. Empresas con más de una 'o'
let muchasO = [];
for (let i = 0; i < itCompanies.length; i++) {
  let count = 0;
  for (let char of itCompanies[i].toLowerCase()) {
    if (char === 'o') count++;
  }
  if (count > 1) muchasO.push(itCompanies[i]);
}
console.log("Empresas con más de una 'o':", muchasO);

// 15. Ordenar
console.log("Ordenado:", itCompanies.sort());

// 16. Invertir
console.log("Invertido:", itCompanies.reverse());

// 17. Cortar las primeras 3 empresas
console.log("Primeras 3:", itCompanies.slice(0, 3));

// 18. Cortar las últimas 3 empresas
console.log("Últimas 3:", itCompanies.slice(-3));

// 19. Cortar intermedia
let middleIndex = Math.floor(itCompanies.length / 2);
console.log("Empresa intermedia:", itCompanies.slice(middleIndex, middleIndex + 1));

// 20. Eliminar primera
itCompanies.shift();
console.log("Sin primera:", itCompanies);

// 21. Eliminar intermedia
middleIndex = Math.floor(itCompanies.length / 2);
itCompanies.splice(middleIndex, 1);
console.log("Sin intermedia:", itCompanies);

// 22. Eliminar última
itCompanies.pop();
console.log("Sin última:", itCompanies);

// 23. Eliminar todas
itCompanies = [];
console.log("Todas eliminadas:", itCompanies);