let fruits = ["Banana", "Manzana", "Fresa"];

fruits.unshift("Cereza");

fruits.push("Melocotón");

console.log("Con forEach:");
fruits.forEach(fruit => console.log(fruit));

fruits.shift();

fruits.pop();

console.log("Con for...of:");
for (const fruit of fruits) {
  console.log(fruit);
}
