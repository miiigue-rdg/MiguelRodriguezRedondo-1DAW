let disney = [
    { nombre: "Hércules", pelicula: "Hércules" },
    { nombre: "Megana", pelicula: "Hércules" },
    { nombre: "Hades", pelicula: "Hércules" },
    { nombre: "Campanilla", pelicula: "Peter Pan" },
    { nombre: "Wendy", pelicula: "Peter Pan" }
  ];

  disney.push({ nombre: "Peter Pan", pelicula: "Peter Pan" });

  console.log("Array completo:", disney);

  disney.unshift({ nombre: "Capitán Garfio", pelicula: "Peter Pan" });

  disney.splice(1, 0, { nombre: "Cocodrilo", pelicula: "Peter Pan" });

  console.log("Personajes de Peter Pan:");
  disney.forEach(personaje => {
    if (personaje.pelicula === "Peter Pan") {
      console.log(personaje);
    }
  });

  const indiceCampanilla = disney.findIndex(p => p.nombre === "Campanilla");
  console.log("Índice de Campanilla:", indiceCampanilla);

  const cocodrilo = disney.find(p => p.nombre === "Cocodrilo");
  console.log("Cocodrilo:", cocodrilo);

  function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      let j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }
  
  shuffle(disney);
  console.log("Array barajado:", disney);
  