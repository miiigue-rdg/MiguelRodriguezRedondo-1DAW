let grupos = [
    {nombre: "ACDC", genero: "Rock"},
    {nombre: "Cold Play", genero: "Pop"},
    {nombre: "NCT Dream", genero: "K-Pop"},
    {nombre: "Metallica", genero: "Heavy Metal"}
  ];
  
  let heavyMetal = grupos.filter(g => g.genero === "Heavy Metal");
  let coldPlay = grupos.find(g => g.nombre === "Cold Play");
  let posicion = grupos.findIndex(g => g.nombre === "Cold Play");
  
  console.log("Grupos Heavy Metal:", heavyMetal);
  console.log("Cold Play:", coldPlay);
  console.log("Posición de Cold Play:", posicion);
  