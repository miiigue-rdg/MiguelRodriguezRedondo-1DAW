public class NumeroNoValidoParaJugar extends Exception{
	public NumeroNoValidoParaJugar(){
		super();
	}
	public NumeroNoValidoParaJugar(String mensaje){
		super(mensaje);
	}
}