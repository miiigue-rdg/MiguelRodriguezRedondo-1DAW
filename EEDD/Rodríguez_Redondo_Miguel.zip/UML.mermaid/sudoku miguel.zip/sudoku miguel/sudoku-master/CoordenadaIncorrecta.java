public class CoordenadaIncorrecta extends Exception{
	public CoordenadaIncorrecta(){
		super();
	}
	public CoordenadaIncorrecta(String mensaje){
		super(mensaje);
	}
}