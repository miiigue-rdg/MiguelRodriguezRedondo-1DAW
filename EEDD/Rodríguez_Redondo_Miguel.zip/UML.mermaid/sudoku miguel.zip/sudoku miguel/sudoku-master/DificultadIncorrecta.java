public class DificultadIncorrecta extends Exception{
	public DificultadIncorrecta(){
		super();
	}
	public DificultadIncorrecta(String mensaje){
		super(mensaje);
	}
}