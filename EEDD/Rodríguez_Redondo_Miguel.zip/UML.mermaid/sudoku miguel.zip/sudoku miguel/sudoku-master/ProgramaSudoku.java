import java.util.Scanner;
public class ProgramaSudoku extends MetodosParaJugar {
	public static void main(String[] args) {
		inicializar();
		jugar();
	}
}