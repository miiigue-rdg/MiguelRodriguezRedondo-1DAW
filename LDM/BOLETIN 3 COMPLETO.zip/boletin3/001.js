

let thor = "Thor es el hijo de Odín";

console.log("Largo:", thor.length);


console.log("Primera 'o':", thor.indexOf("o"));

console.log("Carácter en posición 3:", thor.charAt(3));


console.log("Carácter en posición 1:", thor[1]);


console.log("Troceado:", thor.split(" "));


console.log("Reemplazo:", thor.replace("Thor", "Loki"));


console.log("Recorte:", thor.slice(-4));

console.log("Contiene 'a'?:", thor.includes("a"));

let mitad = Math.floor(thor.length / 2);
console.log("Mitad minúsculas:", thor.slice(0, mitad) + thor.slice(mitad).toLowerCase());