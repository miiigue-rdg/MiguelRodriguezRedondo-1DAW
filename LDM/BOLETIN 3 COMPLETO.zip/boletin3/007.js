const code = new Set();

code.add("JavaScript");
code.add("Python");
code.add("Java");
code.add("JavaScript");
code.add("C++");

console.log("Contenido inicial del Set:", code);

console.log("¿El Set contiene 'Java'? ", code.has("Java"));
console.log("¿El Set contiene 'Ruby'? ", code.has("Ruby"));

code.delete("C++");
console.log("Contenido del Set tras eliminar 'C++':", code);

console.log("Elementos del Set:");
code.forEach(language => {
    console.log(language);
});

console.log("Tamaño del Set:", code.size);

code.clear();
console.log("Set tras clear():", code);
console.log("Tamaño del Set tras clear():", code.size);
