const dog = {};

console.log(dog);

dog.name = "Firulais";
dog.legs = 4;
dog.color = "marrón";
dog.age = 3;
dog.bark = function() {
    return "woof woof";
};

console.log(dog.name);
console.log(dog.legs);
console.log(dog.color);
console.log(dog.age);
console.log(dog.bark());

dog.breed = "Labrador";
dog.getDogInfo = function() {
    return `${this.name} es un ${this.breed} de color ${this.color}, tiene ${this.legs} patas y ${this.age} años.`;
};

console.log(dog);
console.log(dog.getDogInfo());
