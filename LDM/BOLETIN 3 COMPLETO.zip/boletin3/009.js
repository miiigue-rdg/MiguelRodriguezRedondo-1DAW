function hogwartsStudent(nombre, casa, mascota, asignaturas, año, sangre, prefecto) {
    return {
        nombre,
        casa,
        mascota,
        asignaturas,
        año,
        sangre,
        prefecto
    };
}

let hermione = hogwartsStudent(
    "Hermione Granger",
    "Gryffindor",
    "Crookshanks",
    ["Pociones", "Transformaciones", "Encantamientos"],
    3,
    "mestiza",
    true
);

console.log(hermione.nombre);
console.log(hermione.casa);
console.log(hermione.mascota);

hermione.patronus = "Nutria";
hermione.asignaturas.push("Defensa Contra las Artes Oscuras");
hermione.año = 4;
delete hermione.sangre;

function printHogwartsStudent(estudiante) {
    console.log(`${estudiante.nombre} es una estudiante de ${estudiante.casa} en su cuarto año. Tiene una mascota llamada ${estudiante.mascota} y su patronus es una ${estudiante.patronus}. Sus asignaturas son: ${estudiante.asignaturas.join(", ")}.`);
}

printHogwartsStudent(hermione);

let ginny = hogwartsStudent(
    "Ginny Weasley",
    "Gryffindor",
    "Arnold",
    ["Encantamientos", "Vuelo", "Pociones", "Defensa Contra las Artes Oscuras"],
    4,
    "pura",
    false
);

ginny.patronus = "Caballo";
delete ginny.sangre;

printHogwartsStudent(ginny);
