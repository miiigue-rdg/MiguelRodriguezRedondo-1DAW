const personajesUp = new Map();

personajesUp.set("Carl Fredricksen", "Protagonista principal");
personajesUp.set("Russell", "Explorador entusiasta");
personajesUp.set("Dug", "Perro que habla");
personajesUp.set("Kevin", "Ave tropical gigante");
personajesUp.set("Charles Muntz", "Antagonista");

console.log("Contenido inicial del Map:", personajesUp);

console.log("¿Existe 'Russell'?", personajesUp.has("Russell"));
console.log("¿Existe 'Alpha'?", personajesUp.has("Alpha"));

console.log("Rol de 'Dug':", personajesUp.get("Dug"));

personajesUp.set("Russell", "Explorador leal y valiente");
console.log("Nuevo rol de 'Russell':", personajesUp.get("Russell"));

personajesUp.delete("Charles Muntz");
console.log("Contenido del Map tras eliminar 'Charles Muntz':", personajesUp);

console.log("Personajes en el Map:");
personajesUp.forEach((rol, personaje) => {
    console.log(`${personaje}: ${rol}`);
});

console.log("Cantidad actual de personajes:", personajesUp.size);

personajesUp.clear();
console.log("Map tras clear():", personajesUp);
console.log("Tamaño tras clear():", personajesUp.size);
