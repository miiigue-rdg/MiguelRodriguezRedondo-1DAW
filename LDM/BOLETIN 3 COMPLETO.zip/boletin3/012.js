class Curso {
    constructor(nombre) {
        this.nombre = nombre;
        this.estudiantes = new Set();
    }

    añadirEstudiante(nombre) {
        this.estudiantes.add(nombre);
    }

    eliminarEstudiante(nombre) {
        this.estudiantes.delete(nombre);
    }

    unirConOtroCurso(otroCurso) {
        const conjuntoUnido = new Set([...this.estudiantes, ...otroCurso.estudiantes]);
        return conjuntoUnido;
    }

    estudiantesComunesCon(otroCurso) {
        const comunes = new Set();
        this.estudiantes.forEach(est => {
            if (otroCurso.estudiantes.has(est)) {
                comunes.add(est);
            }
        });
        return comunes;
    }

    contieneEstudiante(nombre) {
        return this.estudiantes.has(nombre);
    }

    vaciarCurso() {
        this.estudiantes.clear();
    }
}


const cursoJS = new Curso("JavaScript");
const cursoPython = new Curso("Python");

cursoJS.añadirEstudiante("Ana");
cursoJS.añadirEstudiante("Luis");
cursoJS.añadirEstudiante("Carlos");

cursoPython.añadirEstudiante("Luis");
cursoPython.añadirEstudiante("Lucía");
cursoPython.añadirEstudiante("Carlos");

console.log("Curso JS:", cursoJS.estudiantes);
console.log("Curso Python:", cursoPython.estudiantes);

cursoJS.eliminarEstudiante("Ana");
console.log("Curso JS tras eliminar a Ana:", cursoJS.estudiantes);

const union = cursoJS.unirConOtroCurso(cursoPython);
console.log("Unión de estudiantes JS y Python:", union);

const comunes = cursoJS.estudiantesComunesCon(cursoPython);
console.log("Estudiantes comunes entre JS y Python:", comunes);

console.log("¿Carlos está en JS?", cursoJS.contieneEstudiante("Carlos"));
console.log("¿Lucía está en JS?", cursoJS.contieneEstudiante("Lucía"));

cursoPython.vaciarCurso();
console.log("Curso Python tras vaciar:", cursoPython.estudiantes);
