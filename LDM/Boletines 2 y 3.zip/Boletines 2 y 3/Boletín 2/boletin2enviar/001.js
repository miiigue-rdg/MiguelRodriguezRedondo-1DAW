// Este bucle for va del 1 al 100, incluye el 100 también
for (let i = 1; i <= 100; i++) {
  // Si el número es múltiplo de 3 y 5 a la vez
  if (i % 3 === 0 && i % 5 === 0) {
    console.log("🧸"); // para múltiplos de 3 y 5
  }
  // Si el número solo es múltiplo de 3
  else if (i % 3 === 0) {
    console.log("🍯"); // para múltiplos de 3
  }
  // Si el número solo es múltiplo de 5
  else if (i % 5 === 0) {
    console.log("🐻"); // para múltiplos de 5
  }
  // Si no es múltiplo de ninguno
  else {
    console.log(i); // se imprime el número normal
  }
}
