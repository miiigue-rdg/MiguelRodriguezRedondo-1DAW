// Pido al usuario los emojis que representan monos y bananas
let entrada = prompt("Ingresa una lista de monos 🐵 y bananas 🍌, por ejemplo 🐵🍌🍌🐵🍌");

// Convierto la cadena en un array para contar fácilmente
let lista = entrada.split("");

// Cuento la cantidad de monos y bananas
let monos = lista.filter(e => e === "🐵").length;
let bananas = lista.filter(e => e === "🍌").length;

// Pregunto cuántas bananas come cada mono
let porMono = parseInt(prompt("¿Cuántas bananas necesita cada mono?"));

// Calculo si hay suficientes
let totalNecesarias = monos * porMono;

if (bananas >= totalNecesarias) {
  alert("¡Sí hay suficientes bananas! 🍌✅");
} else {
  alert("¡Oh no! ¡No hay suficientes bananas para los monos! 😭");
}
