// Pregunto si es almuerzo o cena
let comida = prompt("¿Vas a almorzar o cenar? (escribe 'almorzar' o 'cenar')");

// Pregunto si es vegetariano
let vegetariano = prompt("¿Eres vegetariano? (sí o no)");

let plato = ""; // guardo aquí el plato recomendado

// Reviso las opciones con ifs
if (comida === "almorzar" && vegetariano === "sí") {
  plato = "🥗 Ensalada de quinoa";
} else if (comida === "almorzar" && vegetariano === "no") {
  plato = "🍝 Espaguetis con carne";
} else if (comida === "cenar" && vegetariano === "sí") {
  plato = "🥙 Wrap de vegetales";
} else if (comida === "cenar" && vegetariano === "no") {
  plato = "🍣 Sushi mixto";
}

alert("Te recomendamos: " + plato);
