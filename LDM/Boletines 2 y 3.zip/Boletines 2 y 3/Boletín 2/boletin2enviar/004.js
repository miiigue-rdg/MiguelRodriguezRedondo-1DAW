// Defino el cumpleaños correcto (por ejemplo 10 de Agosto que es mi cumple)
const diaCorrecto = 10;
const mesCorrecto = 8;

// Empiezo con 10 vidas 💚
let vidas = 10;
let adivinado = false;

while (vidas > 0 && !adivinado) {
  // Pido el día al usuario
  let dia = parseInt(prompt("Adivina el día de mi cumple (1-31):"));

  // Pido el mes al usuario
  let mes = parseInt(prompt("Adivina el mes de mi cumple (1-12):"));

  // Verifico si acertó los dos
  if (dia === diaCorrecto && mes === mesCorrecto) {
    alert("¡Has ganado 🏅!! Adivinaste mi cumpleaños 🎉");
    adivinado = true;
  } else {
    vidas--; // Quito una vida
    alert("¡Incorrecto! Te quedan " + vidas + " vidas 💚");
    // Pregunto si quiere seguir jugando
    let seguir = prompt("¿Quieres seguir jugando? (sí/no)");
    if (seguir.toLowerCase() !== "sí") {
      break; // Sale del bucle si no quiere seguir
    }
  }
}

if (!adivinado && vidas === 0) {
  alert("Has perdido 😿 !!! No adivinaste el cumple.");
}
