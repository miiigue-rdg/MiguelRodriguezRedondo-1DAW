// Creo una lista para guardar los ingredientes que tiene el usuario
let ingredientes = [];

// Pregunto por 5 ingredientes uno por uno
for (let i = 1; i <= 5; i++) {
  let tiene = prompt("¿Tienes el ingrediente " + i + "? (sí/no)");
  if (tiene.toLowerCase() === "sí") {
    ingredientes.push("ing" + i); // Guardamos un nombre cualquiera
  }
}

// Cantidad total de ingredientes
let cant = ingredientes.length;

// Lista para guardar las comidas que puede hacer
let comidas = [];

// Reviso según la cantidad de ingredientes
if (cant >= 2) {
  comidas.push("Tostadas con queso 🧀🍞");
  comidas.push("Ensalada rápida 🥗");
}
if (cant >= 3) {
  comidas.push("Tacos caseros 🌮");
  comidas.push("Pasta con verduras 🍝");
}
if (cant >= 4) {
  comidas.push("Pizza personalizada 🍕");
  comidas.push("Hamburguesa gourmet 🍔");
}
if (cant === 5) {
  comidas.push("Paella completa 🥘");
}

// Muestro el resultado
if (comidas.length > 0) {
  alert("Puedes cocinar: \n- " + comidas.join("\n- "));
} else {
  alert("No tienes suficientes ingredientes para cocinar nada 😥");
}
