// Función para verificar si un número pasa el algoritmo de Luhn
function verificarLuhn(numero) {
  // Quito guiones o espacios
  let limpio = numero.replace(/[\s-]/g, "");

  // Convierto en array de números
  let digitos = limpio.split("").map(n => parseInt(n));

  let suma = 0;
  let invertir = digitos.reverse(); // empiezo desde la derecha

  for (let i = 0; i < invertir.length; i++) {
    let n = invertir[i];
    // Multiplico por 2 las posiciones impares (porque ya están invertidas)
    if (i % 2 === 1) {
      n *= 2;
      if (n > 9) {
        n -= 9; // Si es mayor que 9 le restamos 9
      }
    }
    suma += n; // Sumo todo
  }

  // Si el total termina en 0, es válido
  return suma % 10 === 0;
}

// Ejemplo de uso
let numeroTarjeta = prompt("Ingresa un número para verificar (con o sin guiones):");

if (verificarLuhn(numeroTarjeta)) {
  alert("El número es válido ✅");
} else {
  alert("El número NO es válido ❌");
}
