// Función para verificar si un número pasa el algoritmo de Luhn
function verificarLuhn(numero) {
  let limpio = numero.replace(/[\s-]/g, "");
  let digitos = limpio.split("").map(n => parseInt(n));
  let suma = 0;
  let invertir = digitos.reverse();

  for (let i = 0; i < invertir.length; i++) {
    let n = invertir[i];
    if (i % 2 === 1) {
      n *= 2;
      if (n > 9) n -= 9;
    }
    suma += n;
  }

  return suma % 10 === 0;
}

// Función para saber el tipo de tarjeta
function tipoTarjeta(numero) {
  let limpio = numero.replace(/[\s-]/g, "");

  // Primero verifico si pasa Luhn
  if (!verificarLuhn(limpio)) {
    return "invalid ❌";
  }

  // Reviso el tipo según las reglas
  if ((limpio.startsWith("34") || limpio.startsWith("37")) && limpio.length === 15) {
    return "American Express 💳 ✅";
  } else if (limpio.startsWith("4") && (limpio.length === 13 || limpio.length === 16)) {
    return "Visa 💳 ✅";
  } else if (
    ["51", "52", "53", "54", "55"].includes(limpio.substring(0, 2)) &&
    limpio.length === 16
  ) {
    return "MasterCard 💳 ✅";
  }

  // Si no cumple ninguna
  return "invalid ❌";
}

// Pidoel número de tarjeta
let entrada = prompt("Introduce un número de tarjeta:");

// Muestro el resultado
alert("Resultado: " + tipoTarjeta(entrada));
