let racha = 0; // contador de aciertos seguidos
let maxRacha = 0; // guardo la racha máxima

while (true) {
  // Pido al usuario elegir
  let eleccion = prompt("¿Cara (🪙), Cruz (✖️) o SALIR (🚪)?");

  // Si elige salir
  if (eleccion === "🚪") {
    alert("¡Has salido del juego! Tu racha máxima fue: " + maxRacha);
    break; // termino el programa
  }

  // Resultado aleatorio (0 es cara, 1 es cruz)
  let resultado = Math.random() < 0.5 ? "🪙" : "✖️";
  alert("Resultado: " + resultado);

  // Comparo la elección
  if (eleccion === resultado) {
    racha++; // sumamos si acertó
    if (racha > maxRacha) {
      maxRacha = racha; // actualizo si es nueva racha máxima
    }
    alert("¡Acertaste! Racha actual: " + racha);
  } else {
    racha = 0; // reinicio si falla
    alert("Fallaste 😢. Racha reiniciada.");
  }
}
