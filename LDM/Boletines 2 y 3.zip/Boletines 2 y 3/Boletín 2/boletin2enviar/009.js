// Colores posibles del juego
let colores = ["🔴", "🔵", "🟢", "🟡"];
let secuencia = []; // secuencia de colores que va creciendo
let jugando = true; // control del bucle
let ronda = 0;

while (jugando) {
  // Agrego un color aleatorio nuevo
  let colorNuevo = colores[Math.floor(Math.random() * colores.length)];
  secuencia.push(colorNuevo);
  ronda++;

  // Muestro la secuencia completa
  alert("Simón dice: " + secuencia.join(" "));

  // Pido los colores uno por uno
  for (let i = 0; i < secuencia.length; i++) {
    let colorJugador = prompt("¿Cuál fue el color número " + (i + 1) + "?🔴🔵🟢🟡");

    // Comparo si es igual al de la secuencia
    if (colorJugador !== secuencia[i]) {
      alert("¡Fallaste! Fin del juego 😵\nSobreviviste " + (ronda - 1) + " rondas.");
      jugando = false; // terminamos el bucle
      break;
    }
  }

  // Si no ha perdido, seguimos a la siguiente ronda
  if (jugando) {
    alert("¡Bien! Pasaste la ronda " + ronda + " 🎉");
  }
}
