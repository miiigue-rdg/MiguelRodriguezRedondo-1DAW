// Valores iniciales del juego
let vidaJugador = 100; // ❤️ vida de la jugadora
let vidaMonstruo = 120; // 💜 vida del monstruo
let pociones = 3; // 🧪 cantidad de pociones
let ataqueJugadorMax = 25; // ⚔️ daño máximo que puede hacer el jugador
let ataqueMonstruoMax = 20; // 👾 daño máximo del monstruo
let curaPocionMax = 30; // 🩺 curación máxima de una poción

// Bucle principal del juego
while (vidaJugador > 0 && vidaMonstruo > 0) {
  // Muestro opciones
  let accion = prompt(
    "¿Qué quieres hacer?\n1. ATACAR MONSTRUO ⚔️\n2. TOMAR POCIÓN 🧪\n3. BUSCAR POCIÓN 🔍\n4. SALIR 🚪"
  );

  if (accion === "1") {
    // Atacar al monstruo
    let daño = Math.floor(Math.random() * ataqueJugadorMax) + 1;
    vidaMonstruo -= daño;
    alert("¡Le diste " + daño + " de daño al monstruo! 💥");

  } else if (accion === "2") {
    // Tomar poción si hay
    if (pociones > 0) {
      let cura = Math.floor(Math.random() * curaPocionMax) + 1;
      vidaJugador += cura;
      pociones--;
      alert("¡Te curaste " + cura + " puntos! 🩺 Te quedan " + pociones + " pociones.");
    } else {
      alert("¡No tienes más pociones! 😓");
    }

  } else if (accion === "3") {
    // Buscar poción
    let suerte = Math.floor(Math.random() * 4) + 1; // de 1 a 4
    if (suerte === 1) {
      pociones++;
      alert("¡Encontraste una poción nueva! 🧪 Ahora tienes " + pociones);
    } else {
      alert("No encontraste nada... 😞");
    }

  } else if (accion === "4") {
    // Salir del juego
    alert("Has salido del juego. 😔");
    break;
  } else {
    alert("Opción inválida. Elige 1, 2, 3 o 4.");
    continue;
  }

  // Ataque del monstruo (si seguimos en juego)
  if (vidaMonstruo > 0 && accion !== "4") {
    let dañoMonstruo = Math.floor(Math.random() * ataqueMonstruoMax) + 1;
    vidaJugador -= dañoMonstruo;
    alert("¡El monstruo te atacó y te hizo " + dañoMonstruo + " de daño! 👾");
  }

  // Muestro las vidas después del turno
  alert(
    "❤️ Tu vida: " + vidaJugador + "\n💜 Vida del monstruo: " + vidaMonstruo
  );
}

// Al terminar el combate, veo quién ha ganado
if (vidaJugador <= 0 && vidaMonstruo <= 0) {
  alert("¡Ambos han caído! Empate épico 😱");
} else if (vidaJugador <= 0) {
  alert("Has sido derrotado... 😵💀");
} else if (vidaMonstruo <= 0) {
  alert("¡Ganaste el combate! 🎉 El monstruo ha sido vencido 🧟‍♂️");
}
