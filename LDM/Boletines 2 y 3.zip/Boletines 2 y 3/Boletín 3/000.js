// Declaro un array vacío
let vacio = [];

// Declaro un array con más de 5 elementos
let numeros = [10, 20, 30, 40, 50, 60, 70];

// Muestro la longitud del array
console.log("Longitud del array:", numeros.length);

// Saco el primer, el del medio y el último elemento
console.log("Primero:", numeros[0]);
console.log("Medio:", numeros[Math.floor(numeros.length / 2)]);
console.log("Último:", numeros[numeros.length - 1]);

// Array con diferentes tipos de datos
let mixedDataTypes = [42, "hola", true, null, {nombre: "algo"}, [1,2]];
console.log("Longitud mixedDataTypes:", mixedDataTypes.length);

// Array de empresas tecnológicas
let itCompanies = ["Facebook", "Google", "Microsoft", "Apple", "IBM", "Oracle", "Amazon"];
console.log(itCompanies); // Imprime todo el array

// Número de empresas
console.log("Total de empresas:", itCompanies.length);

// Primer, intermedia y última empresa
console.log("Primera:", itCompanies[0]);
console.log("Intermedia:", itCompanies[Math.floor(itCompanies.length / 2)]);
console.log("Última:", itCompanies[itCompanies.length - 1]);

// Imprimo cada empresa por separado
for (let empresa of itCompanies) {
  console.log(empresa);
}

// Cambio cada empresa a mayúsculas
for (let i = 0; i < itCompanies.length; i++) {
  console.log(itCompanies[i].toUpperCase());
}

// Convierto a oración
console.log(itCompanies.join(", ") + " son grandes empresas de TI.");

// Compruebo si existe una empresa
let buscar = "Google";
if (itCompanies.includes(buscar)) {
  console.log(buscar + " existe en el array.");
} else {
  console.log(buscar + " no existe.");
}

// Filtro empresas con más de una 'o'
for (let empresa of itCompanies) {
  let cantidad = empresa.toLowerCase().split("o").length - 1;
  if (cantidad > 1) {
    console.log("Empresa con más de una 'o':", empresa);
  }
}

// Ordeno el array
console.log("Ordenado:", itCompanies.sort());

// Invierto el array
console.log("Invertido:", itCompanies.reverse());

// Corto las primeras 3
console.log("Primeras 3:", itCompanies.slice(0, 3));

// Corto las últimas 3
console.l
