let thor = "Thor es el hijo de Odín";

// Largo de la cadena
console.log("Largo:", thor.length);

// Encontrar la letra o
console.log("Primera 'o' está en la posición:", thor.indexOf("o"));

// Carácter en la posición 3
console.log("Posición 3:", thor[3]);

// Carácter en la posición 1
console.log("Posición 1:", thor[1]);

// Trocear usando los espacios
let partes = thor.split(" ");
console.log("Partes:", partes);

// Reemplazar Thor por Loki
let reemplazo = thor.replace("Thor", "Loki");
console.log("Reemplazado:", reemplazo);

// Recortar para obtener "Odín"
let odin = thor.slice(-4);
console.log("Recorte:", odin);

// Ver si existe la letra "a"
console.log("¿Contiene 'a'?:", thor.includes("a"));

// Mitad en minúsculas sin usar posiciones
let mitadIndex = Math.floor(thor.length / 2);
let primeraMitad = thor.substring(0, mitadIndex).toLowerCase();
let segundaMitad = thor.substring(mitadIndex);
console.log("Mitad en minúscula:", primeraMitad + segundaMitad);
