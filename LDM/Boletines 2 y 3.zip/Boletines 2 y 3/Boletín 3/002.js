let fruits = ["Banana", "Manzana", "Fresa"];

// Añado cereza al principio
fruits.unshift("Cereza");

// Añado melocotón al final
fruits.push("Melocotón");

// Muestro todos los elementos con forEach
fruits.forEach(function(fruta) {
  console.log("Fruta con forEach:", fruta);
});

// Elimino el primer elemento
fruits.shift();

// Elimino el último elemento
fruits.pop();

// Muestro cada elemento con for...of
for (let fruta of fruits) {
  console.log("Fruta con for...of:", fruta);
}
