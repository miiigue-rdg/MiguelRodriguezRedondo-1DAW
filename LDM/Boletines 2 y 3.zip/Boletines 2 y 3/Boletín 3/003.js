let disney = [
  { nombre: "Hércules", pelicula: "Hércules" },
  { nombre: "Megana", pelicula: "Hércules" },
  { nombre: "Hades", pelicula: "Hércules" },
  { nombre: "Campanilla", pelicula: "Peter Pan" },
  { nombre: "Wendy", pelicula: "Peter Pan" }
];

// Agrego a Peter Pan al final
// push lo mete al final del array
disney.push({ nombre: "Peter Pan", pelicula: "Peter Pan" });

// Pinto el array completo
console.log("Personajes Disney:", disney);

// Agrego al Capitán Garfio al principio con unshift
// unshift lo pone al inicio del array
disney.unshift({ nombre: "Capitán Garfio", pelicula: "Peter Pan" });

// Meto al Cocodrilo justo después del capitán
// uso splice para insertarlo en la posición 1
// 0 borra nada, el objeto nuevo es el cocodrilo
disney.splice(1, 0, { nombre: "Cocodrilo", pelicula: "Peter Pan" });

// Filtro los personajes de Peter Pan
let peterPanChars = disney.filter(personaje => personaje.pelicula === "Peter Pan");

// Muestro uno por uno los personajes de Peter Pan
peterPanChars.forEach(p => console.log("Peter Pan personaje:", p.nombre));

// Busco el índice de Campanilla con findIndex
let indexCampanilla = disney.findIndex(p => p.nombre === "Campanilla");
console.log("Campanilla está en la posición:", indexCampanilla);

// Buscar al cocodrilo con find
let cocodrilo = disney.find(p => p.nombre === "Cocodrilo");
console.log("Cocodrilo encontrado:", cocodrilo);

// Función para barajar el array (orden aleatorio)
function shuffle(array) {
  // algoritmo de Fisher-Yates
  for (let i = array.length - 1; i > 0; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]]; // intercambio
  }
}

shuffle(disney);
console.log("Disney barajado:", disney);
