// Creo varios objetos que representan bandas
let acdc = { name: "ACDC", age: 25 };
let metallica = { name: "Metallica", age: 30 };
let guns = { name: "Guns and Roses", age: 28 };

// Meto los objetos dentro de un array llamado bands
let bands = [acdc, metallica, guns];

// Uso map() para sacar solo los nombres de cada banda
let names = bands.map(function(banda) {
  return banda.name; // De cada objeto solo devolvemos la propiedad 'name'
});

// Muestro los nombres de las bandas
alert("Nombres de las bandas: " + names.join(", "));
