// Array con varias bandas y su género
let grupos = [
  { nombre: "ACDC", genero: "Rock" },
  { nombre: "Cold Play", genero: "Pop" },
  { nombre: "NCT Dream", genero: "K-Pop" },
  { nombre: "Metallica", genero: "Heavy Metal" }
];

// Filtro solo los que son Heavy Metal
let metal = grupos.filter(grupo => grupo.genero === "Heavy Metal");
console.log("Grupos de Heavy Metal:");
console.log(metal);

// Busco el grupo llamado Cold Play
let coldplay = grupos.find(grupo => grupo.nombre === "Cold Play");
console.log("Grupo encontrado con find:");
console.log(coldplay);

// Busco en qué posición está Cold Play
let indexColdPlay = grupos.findIndex(grupo => grupo.nombre === "Cold Play");
console.log("Cold Play está en la posición:", indexColdPlay);
