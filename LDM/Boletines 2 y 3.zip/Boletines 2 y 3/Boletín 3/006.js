// Función que devuelve un array con 7 números aleatorios y únicos del 0 al 9
function getSevenUniqueNumbers() {
  let numeros = new Set();

  // Sigo agregando hasta tener 7 diferentes
  while (numeros.size < 7) {
    let numero = Math.floor(Math.random() * 10);
    numeros.add(numero); // el Set evita duplicados automáticamente
  }

  // Convierto el Set a array
  return Array.from(numeros);
}

let resultado = getSevenUniqueNumbers();
console.log("7 números únicos aleatorios del 0 al 9:");
console.log(resultado);
