// Creo un Set vacío llamado code
let code = new Set();

// Añado lenguajes de programación
code.add("JavaScript");
code.add("Python");
code.add("Java");
code.add("JavaScript"); // Este está repetido y no se añadirá
code.add("C++");

// Muestroel contenido del Set
console.log("Contenido inicial del Set:");
console.log(code);

// Compruebo si hay "Java" y "Ruby"
console.log("¿Tiene Java?", code.has("Java"));
console.log("¿Tiene Ruby?", code.has("Ruby"));

// Elimino "C++"
code.delete("C++");
console.log("Set después de eliminar C++:");
console.log(code);

// Repito con forEach para ver cada lenguaje
console.log("Elementos en el Set:");
code.forEach(lenguaje => console.log(lenguaje));

// Veo cuántos elementos hay
console.log("Tamaño del Set:", code.size);

// Limpio el Set
code.clear();
console.log("Set vacío:", code);
console.log("Tamaño después de limpiar:", code.size);

