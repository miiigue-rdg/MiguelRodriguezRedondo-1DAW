// Creo un objeto vacío llamado dog 
let dog = {};

// Muestro el objeto vacío
console.log("Objeto dog vacío:", dog);

// Añado propiedades al objeto dog
dog.name = "Firulais";      // Nombre del perro
dog.legs = 4;               // Número de patas
dog.color = "marrón";       // Color del perro
dog.age = 5;                // Edad del perro

// Agrego una función dentro del objeto (propiedad tipo método)
dog.bark = function() {
  return "guau guau"; // El sonido que hace el perro
};

// Muestro las propiedades del perro
console.log("Nombre:", dog.name);
console.log("Patas:", dog.legs);
console.log("Color:", dog.color);
console.log("Edad:", dog.age);
console.log("Ladrido:", dog.bark());

// Añado más propiedades nuevas
dog.breed = "Labrador"; // Raza del perro

// Método que devuelve info del perro
dog.getDogInfo = function() {
  return `${this.name} es un ${this.breed} de color ${this.color} y tiene ${this.age} años.`;
};

console.log(dog.getDogInfo());
