// Creoun objeto con datos de un estudiante de Hogwarts
let hogwartsStudent = {
  nombre: "Hermione Granger",
  casa: "Gryffindor",
  mascota: "Crookshanks",
  asignaturas: ["Pociones", "Transformaciones", "Encantamientos"],
  año: 3,
  sangre: "mestiza",
  prefecto: true
};

// Muestro los datos básicos del estudiante
console.log(`${hogwartsStudent.nombre} es de ${hogwartsStudent.casa} y su mascota es ${hogwartsStudent.mascota}`);

// Añado una nueva propiedad: patronus
hogwartsStudent.patronus = "Nutria";

// Agrego una nueva asignatura al final del array
hogwartsStudent.asignaturas.push("Defensa Contra las Artes Oscuras");

// Cambios el año a 4 (porque sube de curso)
hogwartsStudent.año = 4;

// Elimino la propiedad 'sangre'
delete hogwartsStudent.sangre;

// Creo una función que imprime la info del estudiante
function printHogwartsStudent(estudiante) {
  console.log(`${estudiante.nombre} es una estudiante de ${estudiante.casa} en su cuarto año. Tiene una mascota llamada ${estudiante.mascota} y su patronus es una ${estudiante.patronus}. Sus asignaturas son: ${estudiante.asignaturas.join(", ")}.`);
}

// Llamo a la función con Hermione
printHogwartsStudent(hogwartsStudent);

// Reutilizo el objeto para crear a Ginny
let ginny = {
  nombre: "Ginny Weasley",
  casa: "Gryffindor",
  mascota: "Arnold",
  asignaturas: ["Encantamientos", "Vuelo", "Pociones", "Defensa Contra las Artes Oscuras"],
  año: 4,
  patronus: "Caballo",
  prefecto: false
};

// Llamo también con Ginny
printHogwartsStudent(ginny);
