// Creo un Map vacío llamado personajesUp
let personajesUp = new Map();

// Añadimos personajes y su rol en la peli
personajesUp.set("Carl Fredricksen", "Protagonista principal");
personajesUp.set("Russell", "Explorador entusiasta");
personajesUp.set("Dug", "Perro que habla");
personajesUp.set("Kevin", "Ave tropical gigante");
personajesUp.set("Charles Muntz", "Antagonista");

// Muestro el contenido inicial del Map
console.log("Personajes de UP:");
console.log(personajesUp);

// Compruebo si están Russell y Alpha
console.log("¿Está Russell?", personajesUp.has("Russell"));
console.log("¿Está Alpha?", personajesUp.has("Alpha"));

// Obtengo el rol de Dug
console.log("Rol de Dug:", personajesUp.get("Dug"));

// Actualizo el rol de Russell
personajesUp.set("Russell", "Explorador leal y valiente");
console.log("Nuevo rol de Russell:", personajesUp.get("Russell"));

// Elimino a Charles Muntz
personajesUp.delete("Charles Muntz");
console.log("Mapa tras eliminar a Charles Muntz:");
console.log(personajesUp);

// Recorro el mapa
personajesUp.forEach((valor, clave) => {
  console.log(`${clave}: ${valor}`);
});

// Número de personajes actuales
console.log("Número total de personajes:", personajesUp.size);

// Vacio el mapa
personajesUp.clear();
console.log("Mapa vacío:", personajesUp);
console.log("Tamaño actual:", personajesUp.size);
