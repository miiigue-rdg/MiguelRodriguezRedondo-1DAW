// He creado una clase que se llama Curso, sirve para manejar estudiantes en cursos online
class Curso {
  constructor(nombre) {
    // Cada curso tiene un nombre y un conjunto de estudiantes (uso Set para evitar duplicados)
    this.nombre = nombre;
    this.estudiantes = new Set();
  }

  // Esta función añade un estudiante al curso
  agregarEstudiante(nombre) {
    this.estudiantes.add(nombre); // uso add() porque estoy trabajando con un Set
  }

  // Con esta función puedo eliminar un estudiante si se da de baja
  eliminarEstudiante(nombre) {
    this.estudiantes.delete(nombre); // delete() elimina del Set si existe
  }

  // Esta función une los estudiantes de este curso con otro curso que yo le pase
  unirCursos(otroCurso) {
    // Combino los dos sets usando el spread operator
    return new Set([...this.estudiantes, ...otroCurso.estudiantes]);
  }

  // Aquí obtengo los estudiantes que están en los dos cursos (los comunes)
  comunesCon(otroCurso) {
    return new Set([...this.estudiantes].filter(est => otroCurso.estudiantes.has(est)));
  }

  // Esto lo hice para poder comprobar si un estudiante está o no en el curso
  contieneEstudiante(nombre) {
    return this.estudiantes.has(nombre);
  }

  // Y esta función la uso cuando quiero vaciar el curso por completo (por ejemplo, al reiniciar)
  vaciar() {
    this.estudiantes.clear(); // El método clear borra todos los elementos del Set
  }
}

// Aquí empiezo a usar la clase que hice arriba 👇

// Creo un curso de JavaScript
let cursoJS = new Curso("JavaScript");

// Le agrego estudiantes
cursoJS.agregarEstudiante("Ana");
cursoJS.agregarEstudiante("Luis");

// Creo otro curso, esta vez de Python
let cursoPython = new Curso("Python");

// Agrego estudiantes distintos, pero también repito uno para probar los comunes
cursoPython.agregarEstudiante("Luis");
cursoPython.agregarEstudiante("Marta");

// Muestro los estudiantes de cada curso para ver cómo van
console.log("Estudiantes de JavaScript:", cursoJS.estudiantes);
console.log("Estudiantes de Python:", cursoPython.estudiantes);

// Ahora pruebo la función de unir los dos cursos
let unidos = cursoJS.unirCursos(cursoPython);
console.log("Unión de estudiantes:", unidos);

// Y aquí veo quiénes están en los dos cursos
let comunes = cursoJS.comunesCon(cursoPython);
console.log("Estudiantes en común:", comunes);

// Compruebo si Ana está en el curso de JavaScript
console.log("¿Está Ana en JS?", cursoJS.contieneEstudiante("Ana"));

// Y por último, vaciar el curso de JavaScript como si fuera un nuevo trimestre
cursoJS.vaciar();
console.log("Curso JS tras vaciarlo:", cursoJS.estudiantes);
